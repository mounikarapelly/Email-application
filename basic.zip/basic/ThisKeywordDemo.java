package basic;

public class ThisKeywordDemo {
	 int x;
	    ThisKeywordDemo() {
	        System.out.println(this); //prints the adress of the first object
	        System.out.println(this.x);//print the value of the object by default
	        
	    }
	    
	    public static void main(String[] args) {
	         new ThisKeywordDemo();
	         new ThisKeywordDemo();
	    }    


	}



	//this keyword is used to refer a object members that could be variables or methods
	//we can use it only in non static content


