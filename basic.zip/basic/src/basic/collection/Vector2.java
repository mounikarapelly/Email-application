package basic.collection;

import java.util.Vector;

public class Vector2 {

	public static void main(String[] args) {
		Vector v = new Vector(5,2);//here passing the elements it will incease by 2
		v.add(2);
		v.add(2);
		v.add(2);
		v.add(1);
		v.add(2);
		v.add(2);
		v.add(2);
		v.add(3);
		System.out.println(v.capacity());
		System.out.println(v.size());//it will print vector storing values 

	}

}
