package basic.collection;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

public class Arraylistiterator {

	public static void main(String[] args) {
		List<String> a1 = new ArrayList<>();
		a1.add("Mouni");
		a1.add("Sree");
		
		
		a1.add("Druvan");
		a1.add("Nayan");
		a1.add("ravi");
		a1.add("swarupa");
		System.out.println(a1);
		ListIterator<String> itr = a1.listIterator();
		System.out.println("=========in forward dirction===========");
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
		System.out.println("==========in backward dircetion=====");
		while(itr.hasPrevious()) {
			System.out.println(itr.previous());
		}

	}

}
