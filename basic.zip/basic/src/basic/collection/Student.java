package basic.collection;

public class Student {
	int Rollnumber;
	String Name;
	String Address;
	int Phonenumber;
	 Student(int rollnumber, String name, String address, int phonenumber) {
		super();
		Rollnumber = rollnumber;
		Name = name;
		Address = address;
		Phonenumber = phonenumber;
	}
	public String toString() {
		return ""  + Rollnumber  + "" + Name + "" + "" + Address + "" + Phonenumber;
		
		
	}
	
	
	
		

}
