package basic.collection;

import java.util.ArrayList;
import java.util.List;

public class Arraylist1 {

	public static void main(String[] args) {
		List a1 = new ArrayList();
		a1.add("Mouni");
		a1.add("Sree");
		a1.add(23); 
		a1.add(27);
		a1.add(1.5); 
		a1.add(2.5); 
		a1.add('S'); 
		a1.add('M');
		 
		a1.add("Druvan");
		a1.add("Nayan");
		a1.add("ravi");
		a1.add("swarupa");
		System.out.println(a1);
		
	
		
	}

	}

//multi threads accept the at the same time,it is not thread safe,means non-synchronized
