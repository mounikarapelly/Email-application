package basic.collection;

import java.util.Iterator;
import java.util.TreeSet;



public class TreeSetDemo {

	public static void main(String[] args) {
		TreeSet ts = new TreeSet();
		ts.add(10);
		ts.add(2);
		ts.add(7);
		ts.add(16);
		ts.add(67);
		Iterator it= ts.iterator();//accscending order
		while(it.hasNext()) {
			System.out.println(it.next());
		}
		
		System.out.println("==================");
		System.out.println(ts.first());//it print first element
		System.out.println(ts.last());//it print last element
		System.out.println("=======================");
		Iterator it2 = ts.descendingIterator();//descending order
		while(it2.hasNext()) {
			System.out.println(it2.next());
		}
		

	}

}
