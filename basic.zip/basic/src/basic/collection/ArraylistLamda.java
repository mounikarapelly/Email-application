package basic.collection;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ArraylistLamda {

	public static void main(String[] args) {
	List<String> a1 = new ArrayList<>();
	a1.add("AAAAA");
	a1.add("BBBB");
	a1.add("CCCC");
	a1.add("DDDD");
	
	Iterator<String> itr =a1.iterator();
	
	itr.forEachRemaining(a->{
		System.out.println(a);
	});

	}

}
