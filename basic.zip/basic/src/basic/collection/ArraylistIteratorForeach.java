package basic.collection;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ArraylistIteratorForeach {

	public static void main(String[] args) {
		List<String> a1 = new ArrayList<>();
		a1.add("Mouni");
		a1.add("Sree");
		
		
		a1.add("Druvan");
		a1.add("Nayan");
		a1.add("ravi");
		a1.add("swarupa");
		System.out.println(a1);
		//Iterator<String> itr = a1.iterator();
		a1.forEach(a->{
			System.out.println(a);
		});

	}

}
