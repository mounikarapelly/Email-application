package basic.collection;

import java.util.Vector;

public class VectorDemo {

	public static void main(String[] args) {
	Vector v= new Vector();
	
	v.add(1);
	v.add(2);
	v.add(3);
	v.add(4);
	v.add(5);
	v.add(6);
	v.add(7);
	v.add(8);
	v.add(9);
	v.add(10);
	v.add(11);//it will increase by 10+10
	System.out.println(v.capacity());// by default vector capacity is 10
	}

}
//by defauly vector capacity is 10
//if i add 10 elements it will print 20
//vector capacity alawys double ,if i enter 20 elements it will print 40
//in vector capacity each and every time capacity will be double
//single thread accept the same time,it is thread safe ,it is synchronized
//Mainy if we need some amount elment at the time we can use vector
//



