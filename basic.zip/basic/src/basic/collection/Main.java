package basic.collection;

import java.util.Iterator;
import java.util.LinkedList;

public class Main {

	public static void main(String[] args) {
		LinkedList<Employee> l1 = new LinkedList<Employee>();
		LinkedList<Student1> l2= new LinkedList<Student1>();
		LinkedList<Person> l3 = new LinkedList<Person>();
       Student1 s= new Student1("bbb","science");
       Employee e =new Employee(20000,"aaa");
      l1.add(e);
      l2.add(s);
      Iterator<Student1> it= s.iterator();
		while(it.hasNext()) {
			System.out.println(it.next());
		}
       
	}

}