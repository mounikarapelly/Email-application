package basic.collection;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class methods {

	public static void main(String[] args) {
		List<String> a1 = new ArrayList<>();
		a1.add("Mouni");
		a1.add("Sree");
		a1.add("Druvan");
		a1.add("Nayan");
		a1.add("ravi");
		a1.add("swarupa");
		a1.add("Mouni");
		a1.add("Sree");
		a1.add("Mouni");
		a1.add("Sree");
		a1.add("Druvan");
		
		//a1.remove(4);//remove the specified element in the list
		//a1.set(6,"siri");//it replace specified element in the list,present at specified position
		//a1.sort(String.CASE_INSENSITIVE_ORDER);//it returns the alphabetical order in the lsit
		
		//a1.sort(Comparator.naturalOrder());//it returns the first uppercase letters next lowercase in the listS
	    System.out.println(a1.subList(2, 8));//it print the some specified elemts
		List<String> a2 = new ArrayList<>();
		
		a2.add("Mouni");
		a2.add("Sree");
		a2.add("Druvan");
		a2.add("Nayan");
		a2.add("ravi");
		a2.add("swarupa");
		a2.add("jjj");
		
		//a2.add("meena");
		//a2.add("Swetha");
		//a2.add("sravya");
		//a2.add("sravani");
		//a2.add("swethi");
		//a2.add("shilpa");
		//a2.addAll(a1);//addAll method  with element ,combines A2 list in A1 list
		//a2.addAll(2, a1);// addAll method with index position
		//a2.clear();//clear method remove all elements in list2 data i.e a2
		System.out.println(a1);
		//System.out.println(a1.isEmpty());//it returns if list is empty it will print true ow false
		//System.out.println(a1.lastIndexOf("Druvan"));//it returns the last index value,-1 it doesn't contains the element in the list
		//System.out.println(a1.indexOf("Sree"));//it returns the first index value
		//System.out.println(a1.contains("Sree"));//in this passing one element if it contains in list it will print true, ow it will print false
		//System.out.println(a1.equals(a2));//equals method compare both list a1 and list a2 elemnets.if elements are equal then print true ow false
//		for(String s:a1) {     // for each loop prints the A1 list
//			System.out.println(s);
//	}
//		System.out.println();
//		
//		
//		System.out.println(a2);
//		for(String x:a2) {
//			System.out.println(x);
//	}

	}
}
