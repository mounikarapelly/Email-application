package basic.collection;

import java.util.HashSet;
import java.util.Iterator;


public class HashSetDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		HashSet hs = new HashSet();
		hs.add(1);
		hs.add(2);
		hs.add(5);
		hs.add(8);
		hs.add(1);
		hs.add("mouni");
		hs.add("ramu");
		hs.add("ravi");
		hs.add("vasantha");
		
		System.out.println(hs);
		Iterator it =hs.iterator();
		while(it.hasNext()) {
			System.out.println(it.next());
		}
		
		

	}

}
