package basic.collection;

import java.util.ArrayList;
import java.util.*;

import javax.swing.text.html.HTMLDocument.Iterator;

public class Arrayiteratormethod {

	public static void main(String[] args) {
		List<String> a1 = new ArrayList<>();
		a1.add("Mouni");
		a1.add("Sree");
		
		
		a1.add("Druvan");
		a1.add("Nayan");
		a1.add("ravi");
		a1.add("swarupa");
		System.out.println(a1);
		Iterator itr = (Iterator) a1.iterator();
		//while(((Object) itr).hashNext()) {
		//	System.out.println(((Iterator) a1).next());
		//}

	}

}
