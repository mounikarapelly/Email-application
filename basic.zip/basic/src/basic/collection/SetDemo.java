package basic.collection;

public class SetDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		

	}

}

//set interface--->
//HashSet
//Linkedhashset
//Treeset
//
//         hashset                              linkedhashset              treeset
// ORDER-It doesnt follows insertion order||  it follows insertion order||  it follos sorting
//
//duplicate values--no                                 no                        no

// synchroized --no                                      no                       no

//data structure --hashtable                           hashtable+doublelinkedlist ||     it stores the element blanced tree

// capacity ----16                                         16                            -----
//
//
//
//
//
