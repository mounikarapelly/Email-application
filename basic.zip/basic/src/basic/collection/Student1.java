package basic.collection;

import java.util.Iterator;

public class Student1 extends Person {
	String name;
    String dept;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDept() {
		return dept;
	}
	public void setDept(String dept) {
		this.dept = dept;
	}

    void display(){
        System.out.println(name+" "+dept);
    }
	public Student1(String name, String dept) {
		super();
		this.name = name;
		this.dept = dept;
	}
	public Iterator<Student1> iterator() {
		// TODO Auto-generated method stub
		return null;
	}
}
