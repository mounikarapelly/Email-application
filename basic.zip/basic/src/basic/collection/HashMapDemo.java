package basic.collection;

import java.util.HashMap;

public class HashMapDemo {

	public static void main(String[] args) {
		HashMap hm = new HashMap();
		hm.put("name","Mouni");
		hm.put("name2","SREE");
		System.out.println(hm);
	}

}

//hashmap contains key and value pair
//key value must be unique value& value duplicate value allowed
//it doesn't follow insertion order
//key+value =called entry level

