package basic.collection;

import java.util.ArrayList;
import java.util.List;

public class Arraylist2Index {

	public static void main(String[] args) {
		List<String> a1 = new ArrayList<>();
		a1.add("Mouni");
		a1.add("Sree");
		
		
		a1.add("Druvan");
		a1.add("Nayan");
		a1.add("ravi");
		a1.add("swarupa");
		System.out.println(a1);
		for(int i=0;i<a1.size();i++) {
			//System.out.println(i);
			System.out.println(a1.get(i));
		}

	}

}
