package basic.collection;

import java.util.Iterator;
import java.util.TreeSet;

public class TreeSetDemo2 {

	public static void main(String[] args) {
		TreeSet ts = new TreeSet();
		ts.add(10);
		ts.add(2);
		ts.add(7);
		ts.add(16);
		ts.add(67);
		Iterator it= ts.iterator();//accscending order
		while(it.hasNext()) {
			System.out.println(it.next());
		}
		System.out.println("====================");
		
	TreeSet ts1=(TreeSet) ts.headSet(10);//it will print less values passing the element
	System.out.println(ts1);
	System.out.println("===============");
	TreeSet ts2=(TreeSet) ts.tailSet(16);//it will print high values nd passing the element
	System.out.println(ts2);
	System.out.println("=================");
	TreeSet ts3=(TreeSet) ts.subSet(2,16);//it will print passing the beetween elements
	System.out.println(ts3);
	}
	

}
