package basic.collection;

import java.util.Iterator;
import java.util.LinkedHashSet;

public class LinkedHashSetDemo {

	public static void main(String[] args) {
		
		LinkedHashSet ts = new LinkedHashSet();
		ts.add(10);
		ts.add(20);
		ts.add(100);
		ts.add(3);
		ts.add(11);
		ts.add(30);
		ts.add(50);
		ts.add(10);
		Iterator it= ts.iterator();
		while(it.hasNext()) {
			System.out.println(it.next());
		}

	}

}
