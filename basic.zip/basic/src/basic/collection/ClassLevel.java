package basic.collection;

import java.util.ArrayList;
import java.util.List;
import java.util.*;

public class ClassLevel {

	public static void main(String[] args) {
		List<Student> list =new ArrayList<>();
		
		Student s1 = new Student(1,"Monika","MUT",703211111);
		Student s2 = new Student(2,"Sree","KSP",965211111);
		Student s3 = new Student(3,"Nayan","hyd",703211111);
		Student s4 = new Student(4,"Druvan","Hyd",703211111);
		list.add(s1);//in list adding the objects
		list.add(s2);
		list.add(s3);
		list.add(s4);
		
		for(Student s:list) {
			System.out.println(s.Rollnumber+"   "+s.Name+"  "+s.Address+"  "+s.Phonenumber);
		}
         
	}

}
