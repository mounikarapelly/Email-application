package basic.collection;

import java.util.LinkedList;
import java.util.Scanner;

public class Person {
	//LinkedList<Employee> ll = new LinkedList<Employee>();
	//Scanner keyboard = new Scanner(System.in);
	String address;

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
	


	
}
