package basic;

public class Staticexample {
	
	    static String companyname="capgemini";
	    String empname;
	    int empid;
	    
		/*
		 * static void change() { companyname="mounika"; }
		 */
	    
	    Staticexample(String emp,int eid){
	        empname=emp;
	        empid=eid;
	    }



	void display()
	{
	    System.out.println(companyname+" "+empname+" "+ empid);}
	public static void main(String[] args) {
	   // Staticexample.change();
	    
	    Staticexample st=new Staticexample("samanth",461932);
	    Staticexample st2=new Staticexample("manoj",461923);    
	    st.display();
	    st2.display();
	}
	
}
