package basic;

public class Static {

	
	
}
