package com.productapplication.springbootrest.service;

import java.util.List;

import com.productapplication.springbootrest.model.Product;

public interface IProductService {
	//findAll() method that returns a List of products
	List<Product> findAll(); 

}
