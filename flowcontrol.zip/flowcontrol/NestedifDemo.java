package flowcontrol;

public class NestedifDemo {

	public static void main(String[] args) {
		int x=5;
		int y=6;
		if(x>y) {
			System.out.println("x is higher");
		}
		else if(y<x){
			System.out.println("y is higher");
		}else {
			System.out.println("else block");
		}

	}

}
