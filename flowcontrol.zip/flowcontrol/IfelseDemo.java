package flowcontrol;

public class IfelseDemo {

	public static void main(String[] args) {
		int x=10;
		int y=20;
		if(x<y) {
			System.out.println("x is greater");
			
		}else {
			System.out.println("y is higher");
		}

	}

}
