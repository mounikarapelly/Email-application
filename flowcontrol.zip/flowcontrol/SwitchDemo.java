package flowcontrol;

public class SwitchDemo {

	public static void main(String[] args) {
		int x=1;
		switch(x) {
		case 1:
			System.out.println("case-1");
			break;
		case 2:
			System.out.println("case-2");
			
		case-3:
			System.out.println("case-3");
		default :
			System.out.println("default value");
		
		
	}
	
	}
}


//byte,short,int,char,enum,string
