package springbootweb.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

import springbootweb.model.Product;
import springbootweb.repository.ProductReopository;
//@RequestMapping("/products")
@RestController
public class ProductController {
	@Autowired
	ProductReopository repository;
	
	@RequestMapping("/hello")
	 public String Hello() {
		 return "hi";
	 }
	
	@GetMapping("/product")
	public List<Product> getProducts(){
		return repository.findAll();
		
	}
	@GetMapping("/{productid}")
	public Product getProduct( int id) {
		return repository.findById(id).get();
	}
	@PostMapping("/product")
	public Product createProduct(Product product) {
		return repository.save(product);
		
	}
	@PutMapping("/products")
	public Product updateProduct(Product product) {
		return repository.save(product);
		
	}
	@DeleteMapping("productid")
	public void deleteProduct(int id) {
		repository.deleteById(id);
	}
	

}
