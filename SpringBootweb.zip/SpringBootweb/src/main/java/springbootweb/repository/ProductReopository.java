package springbootweb.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import springbootweb.model.Product;

public interface ProductReopository extends MongoRepository<Product, Integer> {

}
