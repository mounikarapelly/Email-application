package Exception;

public class UserDefinedEx extends Exception {
	public void MinBalanceException()
	    {
	        System.out.println ("Balance is low");
	    }

}
//Define  public class deriving from java.lang.Exception
//Define public no-arg and String parameter constructor with super() call.