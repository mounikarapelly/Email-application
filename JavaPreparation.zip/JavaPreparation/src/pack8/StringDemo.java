package pack8;

public class StringDemo
{
    public static void main (String args[])
    {
        //creating a string by java string literal 
        String str = "Hello World";
        char arr[] = { 'h', 'e', 'l', 'l', 'o' };
        
        //converting char array arraycharacter[] to string str2
        String str2 = new String (arr);

        //creating another java string str3 by using new keyword 
        String str3 = new String ("Java String");
        

        //Displaying all the three strings
        System.out.println (str);
        System.out.println (str2);
        System.out.println (str3);
    }
}