package pack8;

public class BooleanLiteral {

}
