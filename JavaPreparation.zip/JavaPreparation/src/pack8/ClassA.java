package pack8;

public class ClassA {
	public int Car(int a ,int b) {
		System.out.println("Car method");
		System.out.println(a);
		System.out.println(b);
		System.out.println(a+b);
		return 100;
		
	}
	public String Bike() {
		System.out.println("bike meth");
		System.out.println(30);
		return "from bike";
		
	}
	public int Vechile() {
		System.out.println("vechile meth");
		System.out.println(40);
		System.out.println(50);
		return 100;
		
	}

	public static void main(String[] args) {
		
		System.out.println("start");
		ClassA obj = new ClassA();
		String s=obj.Bike();
		System.out.println(s);
		int i=obj.Vechile();
		System.out.println(i);
		int y=obj.Car(10, 20);
		System.out.println(y);
		
		System.out.println("end");

	}

}
