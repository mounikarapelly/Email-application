package pack8;
public class FloatingPointLiteral {
    public static void main(String[] args) {
        double decimalValue = 101.230; // decimal-form literal
        double decimalValue1 = 0123.222; // It also acts as decimal literal
        double hexaDecimalValue = 1.234e2; // Hexa-decimal form
        System.out.println("Decimal form literal is "+decimalValue);
        System.out.println("Second Decimal form literal is "+decimalValue1);
        System.out.println("Hexa decimal form literal is "+hexaDecimalValue);
    }
}
