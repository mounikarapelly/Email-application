package pack8;

public class Basic1 {
	public int meth1(int a) {
		System.out.println("meth1");
		System.out.println(10+a);
		return 20;
		
	}
	public int meth2(int a,int b) {
		System.out.println("meth2");
		System.out.println(10+a+b);
		return a+b;
		
	}
	
	public static void main(String[] args) {
		Basic1 basic1 = new Basic1();
		 int i =basic1.meth1(100);
		 System.out.println("====="+i);
		int x= basic1.meth2(50,200);
		System.out.println("========="+x);


	}

}
