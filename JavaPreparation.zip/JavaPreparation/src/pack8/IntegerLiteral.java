package pack8;



public class IntegerLiteral {
    public static void main(String[] args) {
            int a = 101; // decimal literal 
            int b = 0146; // octal literal 
            int c = 0x123Face; // Hexa-decimal literal 
            int d = 0b1111; // Binary literal 
            System.out.println(a); 
            System.out.println(b); 
            System.out.println(c); 
            System.out.println(d); 
    }
}