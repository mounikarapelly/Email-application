package arrays;

public class ArrayExample2 {
	public static void main(String args[]){  
		int a[]={33,3,4,5};  
		for(int i=0;i<a.length;i++) 
		System.out.println(a[i]);
}
}
