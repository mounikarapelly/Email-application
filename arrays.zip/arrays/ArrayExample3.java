package arrays;

public class ArrayExample3 {
	public static void main(String args[]){  
		int arr[]={33,3,4,5};   
		for(int i:arr)  
		System.out.println(i);  

}
}
