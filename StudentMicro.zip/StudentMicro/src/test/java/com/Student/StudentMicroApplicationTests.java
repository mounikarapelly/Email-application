package com.Student;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentMicroApplicationTests {

	@Test
	void contextLoads() {
	}

}
