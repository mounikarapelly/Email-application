package pack1.basic;

import java.util.List;

public class Mapping {

	public static void main(String[] args) {
		
		
		List<String> courses =
				List.of("spring","springboot","java","microservices",
						"aws","database");
		 courses.stream()//only 
			.map(course-> course + " ==="+course.length())
			.forEach(System.out::println);
		
		System.out.println("======");
		List<Integer> numbers =List.of(2,8,3,5,16,12);
		System.out.println("sqaure numers");
		System.out.println("======");
		
		printSquareNumbersInListFunctional(numbers);
		
		
		
		System.out.println("cube numers");
		System.out.println("======");
		
		printCubeNumbersInListFunctional(numbers);
		

	}

	private static void printSquareNumbersInListFunctional(List<Integer> numbers) {
		numbers.stream()
		.filter(number -> number % 2  ==0)//lamdba expression
		.map(number->number*number)//it maps the every number
		.forEach(System.out::println);
		
	}
	
	
	
private static void printCubeNumbersInListFunctional(List<Integer> numbers) {
		
		numbers.stream()
		.filter(number -> number % 2  !=0)//lamdba expression
		.map(number-> number*number*number)
		.forEach(System.out::println);
		
		
	}


}
