package pack1.basic;

import java.nio.file.DirectoryStream.Filter;
import java.util.List;

public class FunctionalOddnnumbers {

	public static void main(String[] args) {
		List<Integer> numbers =List.of(12,23,2,5,10,15,2,6,8);
		System.out.println("odd numers");
		System.out.println("======");
		
		printOddNumbersInListFunctional(numbers);//its print all the odd numbers
		
		System.out.println("list of all courses");
		System.out.println("===========");
		System.out.println();
		List<String> courses =
				List.of("spring","springboot","java","microservices",
						"aws","database");
		
		courses.stream()//all the courses
		.forEach(System.out::println);
		System.out.println();
       System.out.println("only start with s letter");
		System.out.println("==========");
		
		
       courses.stream()//only spring courses
		.filter(course -> course.contains("spring"))
		.forEach(System.out::println);
       System.out.println();
       System.out.println("only above 4 letter courses");
       System.out.println("=============");
       
       courses.stream()//only 
		.filter(course -> course.length()>=4)
		.forEach(System.out::println);

	}
	private static void printOddNumbersInListFunctional(List<Integer> numbers) {
		
		numbers.stream()
		.filter(number -> number % 2  !=0)//lamdba expression
		
		.forEach(System.out::println);
		
		
	}

}
