package pack1.basic;

import java.util.List;

public class FunctionStrucured {

	public static void main(String[] args) {
		//printAllNumbersInListFunctional(List.of(12,2,3,5,7,5,12,25,15,15));
		
		List<Integer> numbers =List.of(12,2,3,5,7,5,12,25,15,4,14,8,12);
		System.out.println("list of all numbers");
		printAllNumbersInListFunctional(numbers);
		System.out.println("list of even numebrs");
		printEvenNumbersInListFunctional(numbers);

	}
	//private static void print(int number) {
	//	System.out.println(number);
	//}
	/*
	 * private static boolean isEven(int number) { return number%2==0;
	 * 
	 * }
	 */

	private static void printAllNumbersInListFunctional(List<Integer> numbers) {
		/*
		 * for(int number:numbers) { System.out.println(numbers); }
		 */
		numbers.stream()
		//.forEach(FunctionStrucured::print);//method reference
		.forEach(System.out::println);
		
		
	}
	private static void printEvenNumbersInListFunctional(List<Integer> numbers) {
		/*
		 * for(int number:numbers) { System.out.println(numbers); }
		 */
		numbers.stream()
		.filter(number -> number%2 ==0)//lamdba expression
		//.filter(FunctionStrucured::isEven)//filter only even numbers
		//.forEach(FunctionStrucured::print);//method reference
		.forEach(System.out::println);
		
		
	}

}
