package pack1.basic;

import java.util.List;

public class SumFunctional {
	
	public static void main(String[] args) {
		List<Integer> numbers =List.of(2,8,3,5,16,12);
           int sum = addListStructured(numbers);
           System.out.println("sum of the list value"+sum);
	}
	
	private static int sum(int a, int b) {
		return a+b;
		
	}
	
	

	private static int addListStructured(List<Integer> numbers) {
		//stream of numbers->on eresult value
		//combine them into one result=>one value
		//0 and clsassname::method anme
		return numbers.stream()
				.reduce(0, SumFunctional::sum);
	}

}
