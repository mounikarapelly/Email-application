package pack1.basic;

import java.util.List;

public class Sumclass {

	public static void main(String[] args) {
		List<Integer> numbers =List.of(2,8,3,5,16,12);
           int sum = addListStructured(numbers);
           System.out.println("sum of the list value"+sum);
	}

	private static int addListStructured(List<Integer> numbers) {
		int sum=0;
		for(int number: numbers) {
			sum += number;
		}
		return sum;
	}

}
