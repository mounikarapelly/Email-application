package Strings;

public class StringBuilderReverse {
	public static void main(String args[]){  
		StringBuilder sb=new StringBuilder("Ganga");  
		sb.reverse();  
		System.out.println(sb); 
		}  
}
