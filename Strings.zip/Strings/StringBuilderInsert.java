package Strings;

public class StringBuilderInsert {
	public static void main(String args[]){  
		StringBuilder sb=new StringBuilder("Hello ");  
		sb.insert(1,"world"); 
		System.out.println(sb); 
		}  
}
