package exceptionhandling;

import java.util.Scanner;

public class Finally {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner scanner = new Scanner(System.in);
		int[] numbers = new int[6];

		int num = numbers[5];
		System.out.println(" scanner ");
		scanner.close();
	}



}
