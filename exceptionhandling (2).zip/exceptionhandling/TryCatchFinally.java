package exceptionhandling;

public class TryCatchFinally {

	public static void main(String[] args) {
		try {
			int i = 20 / 0;
			System.out.println("in try");
		} catch (ArithmeticException ae) {
			System.out.println("in catch");
		} finally {
			System.out.println("in finally");
		}
		System.out.println("after try catch finally");
	}

}
