package exceptionhandling;

public class TryCatchex {

	public static void main(String[] args) {
		int i = 50;
			int j = 0;
			int data;
			try {
				data = i / j; // may throw exception
				System.out.println("try blick");
			}

			catch (Exception e) {// handling the exception

				System.out.println(i / (j + 2));
			}

	}

}
