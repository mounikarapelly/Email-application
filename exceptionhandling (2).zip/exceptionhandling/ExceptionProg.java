package exceptionhandling;

public class ExceptionProg {

	void java() {
		System.out.println("java method");
		int data = 50 / 0;
	}

	void spring() {
		System.out.println("spring method");
		java();
	}

	void microservice() {
		System.out.println("micerpsevice method");
		try {
			System.out.println("try block==1");
			spring();
			System.out.println("try block===2");
		} catch (Exception e) {
			System.out.println("exception handled");
		}
	}

	public static void main(String[] args) {
		ExceptionProg exceptionProg = new ExceptionProg();
		exceptionProg.microservice();

	}

}
