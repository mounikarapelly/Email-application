package exceptionhandling;

public class ThrowingExceptionRunner {

	public static void main(String[] args) {
		
		

		Amountexception amount1 = new Amountexception("USD", 10);
		Amountexception amount2 = new Amountexception("USD", 10);

		// Amountexception amount2 = new Amountexception("EUR", 20);
		amount1.add(amount2);
		System.out.println(amount1);

		try {
			amount1.add(amount2);
			System.out.println(amount1);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}



}
