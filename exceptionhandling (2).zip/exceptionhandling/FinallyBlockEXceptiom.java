package exceptionhandling;

public class FinallyBlockEXceptiom {

	public static void main(String args[]) {
		try {// don't throw any exception

			int data = 25 / 5;
			System.out.println(data);
		}

		catch (NullPointerException e) {// not executed
			System.out.println("catch block ");
			System.out.println(e);
		}
// finally block is a block used to execute important code
// such as closing the connection
		finally {
			System.out.println("finally block is always executed");
		}

		System.out.println("rest of phe code...");
	}

}
