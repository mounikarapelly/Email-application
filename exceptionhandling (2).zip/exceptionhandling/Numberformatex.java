package exceptionhandling;

import java.util.Scanner;

public class Numberformatex {

	public static void main(String[] arg) {

		int number;

		Scanner scanner = new Scanner(System.in);
		while (true) {
			System.out.println("Enter any valid Integer: ");

			// Try block to check if any exception occurs
			try {

				number = Integer.parseInt(scanner.next());// Parsing user input to integer
														// using the parseInt() method
				System.out.println("You entered: " + number);
				break;
			}

			// Catch block to handle NumberFormatException
			catch (NumberFormatException e) {

				System.out.println("NumberFormatException occurred");
			}
		}
	}


}

