package exceptionhandling;

import java.io.IOException;

public class ThrowsKeyword {

	void java() throws IOException {
		throw new IOException("device error"); // checked exception
	}

	void spring() throws IOException {
		java();
	}

	void microservice() {
		try {
			spring();
		} catch (Exception e) {
			System.out.println("exception handled");
		}
	}

	public static void main(String args[]) {
		ThrowsKeyword th = new ThrowsKeyword();
		th.microservice();
		System.out.println("normal flow...");
	}
}