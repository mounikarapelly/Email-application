package exceptionhandling;

public class Amountexception {

	private String currency;
	private int amount;

	public Amountexception(String currency, int amount) {
		super();
		this.currency = currency;
		this.amount = amount;
	}

	@Override
	public String toString() {
		return "Amountexception [currency=" + currency + ", amount=" + amount + "]";
	}

	public void add(Amountexception that) {
		if (!this.currency.equals(that.currency)) {
			throw new RuntimeException("Currencies Don't Match");
		}
		this.amount += that.amount;
	}


}
