package core;

import java.util.Scanner;

public class MatrixAddition {

	public static void main(String []args)
		{
		Scanner input=new Scanner(System.in);
		System.out.print("Enter number of rows : ");
		int r=input.nextInt();
		System.out.print("Enter number of columns : ");
		int c=input.nextInt();
		if(r!=c)
			{
			System.out.println("\nSorry! matrix multiplication cannot be performed");
		
			System.exit(0);
			}
				else
				{ 
					int m1[][]=new int[r][c];
					int m2[][]=new int[r][c];
					int m3[][]=new int[r][c];
					int sum;
					System.out.println("enter the first element of matrix row wise"); 
		
						for(int i=0;i<r;i++)
							{
								for(int j=0;j<c;j++)
								{
									m1[i][j]=input.nextInt();
								}
							}
						System.out.println("enter 2nd element of matrix row wise");
						for(int i=0;i<r;i++)
						{
							for(int j=0;j<c;j++)
							{ 
								m2[i][j]=input.nextInt();
							}
						}
						for(int i=0;i<r;i++)
						{
		
							for(int j=0;j<c;j++)
							{ 
								sum=0;
								for(int k=0;k<r;k++)
								{ 
									sum=sum + m1[i][k]*m2[k][j];
								}
								m3[i][j]=sum;
							}
						}
						System.out.println("Product of two matrices : ");
						for(int i=0;i<r;i++)
						{
							for(int j=0;j<c;j++)
							{
								System.out.print(" "+ m3[i][j]);
							}
							System.out.println();
						}
						input.close();
				}
		}

}

