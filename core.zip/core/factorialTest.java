package core;

import java.util.Scanner;

public class factorialTest {
 // Method to find factorial of given number
     static int factorial(int n)
     {
    	 int res = 1, i;
    	 for (i=2; i<=n; i++)
    		 res *= i;
    	 return res;
     }
     // Driver method
     public static void main(String[] args)
     {
    	 Scanner input=new Scanner(System.in);
    	 System.out.print("\nEnter a number to find factorial : ");
    	 int num=input.nextInt();
    	 System.out.println("Factorial of "+ num + " is " +
    			 factorial(num));
     }
}
