package core;

import java.util.Scanner;
import java.util.Vector;

public class VectorExample {
	public static void main(String[] args)
	{ 
		// Size of the Vector
		int n = 5;
		Scanner input = new Scanner(System.in);
		// Declaring the Vector with initial size n
		Vector<Integer> list = new Vector<Integer>(n);
		// Appending new elements at the end of the vector
		try{ 
			for(int i=0;i<5;i++)
				list.add(Integer.parseInt(args[i]));
			// Printing elements of list
			System.out.println("\n"+list);
			// Remove element at index 3
			list.remove(3);
			//Displaying the vector after deletion
			System.out.println(list);
			// iterating over vector elements usign for loop
			System.out.println("Printing the list using list.get()---");
	
			for (int i = 0; i<list.size(); i++)
				// Printing elements one by one
				System.out.print(" "+list.get(i));
			// Creating the array and using toArray()
			Object[] arr = list.toArray();
			System.out.println("\n printing the list using array()--");
	
			for (int i = 0; i<arr.length; i++)
				System.out.print(" "+arr[i]);
			System.out.println();
	
		}
			catch(Exception e)
		{ 	
				System.out.println("\nProgram ended.......");
				System.out.println("Exception : "+e.getMessage());
		}
	}

}
