package core;

public class Throw {
	public static void main(String args[]){
		int balance=5000;
		int withdrawlAmount=6000;
		try
		{ 
			if(balance< withdrawlAmount)
			{ 
				throw new
				ArithmeticException("Insufficient balance");
			}
			balance=balance-withdrawlAmount;
			System.out.println("Transaction successfully completed");

		}
		catch(ArithmeticException e)
		{ 
			System.out.println("\nException: "+ e.getMessage());
		}
		finally
			{
			System.out.println("Program continue.....");
				}
	}
}