package core;

import java.util.Scanner;

public class ArithmeticOperations {
	
	private Scanner input = new Scanner(System.in);
	
	public int Addition(){
	int a = input.nextInt();
	int b = input.nextInt();
	return a+b;
	}
	public int Subtract(){
	int a = input.nextInt();
	int b = input.nextInt();
	return a-b;
	}
	public int Multiplication(){
	int a = input.nextInt();
	int b = input.nextInt();
	return a*b;
	}
	public float Division(){
	float a = input.nextFloat();
	float b = input.nextFloat();
	return a/b;
	}
	
	

}
