package core;


 public class Interface{
	public static void main(String args[]){
		CircleArea cir;
		RectangleArea rect;
		//Creates a Test object
		Test Area = new Test();
		cir = Area;
			System.out.println("\nArea of circle : "+
					cir.compute(49));
			rect = Area;
			System.out.println("Area of Rectangle : " +
					rect.calculate(5,20));
	}
}	