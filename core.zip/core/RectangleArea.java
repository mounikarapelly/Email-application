package core;

public interface RectangleArea {
	 int calculate(int l,int w); //interface method

}
