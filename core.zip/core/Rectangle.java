package core;

import java.util.Scanner;

public class Rectangle extends Shape{
	private int a,b;
	//method overriding
	public void readData(){
		System.out.print("\n\nEnter two sides of Rectangle : ");
		Scanner sidein = new Scanner(System.in);
		a = sidein.nextInt();
		b = sidein.nextInt();
	}
	public void areaCalcultion(){
		int area;
		area = a * b;
		System.out.println("Area of Rectangle is : " + area);
		System.out.println("\n<--------------------------->");
	}
}
class Circle extends Shape{
	private double radius;
		//method overriding
		public void readData(){
			System.out.print("\nEnter Radius of circle : ");
			Scanner radiusin = new Scanner(System.in);
			radius= radiusin.nextDouble();
		}
		public void areaCalcultion(){
			double area = (22/7) * radius * radius;
			System.out.println("Area of circle is : " + area);
		}
	}