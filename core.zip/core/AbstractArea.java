package core;

public class AbstractArea{
	public static void main(String args[]){
		//Reference variable of Shape
		Shape s;
		s= new Rectangle(); // Creating object of abstract class
		s.readData();
		s.areaCalcultion();
		s=new Circle(); // Creating object of abstract class
		s.readData();
		s.areaCalcultion();
	}
}