package core;

public class Prime2 {
	
	 public static void main(String[] args) {
		 

	        int count = 0;
	        

	        for (int i = 2; i < 50; i++) {

	            boolean isPrime = true;

	            for (int j = 2; j < i; j++) {

	                if (i % j == 0) {
	                    isPrime = false;
	                    break;
	                }
	            }

	            if (isPrime) {
	                count++;
	                System.out.print(i + " ");
	            }

	        }
	       
	        System.out.println("\n\n" + count + " prime number's");
	    }
	


}
