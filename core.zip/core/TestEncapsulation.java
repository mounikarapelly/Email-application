package core;

public class TestEncapsulation {
	public static void main(String[] args)
	{ 
		Encapsulate obj = new Encapsulate();
	// setting values of the variables
	obj.setName("mounika");
	obj.setAge(23);
	obj.setRoll(5527);
	// Displaying values of the variables
	System.out.println("Student's name: " +
	obj.getName());
	System.out.println("Student's age: " + obj.getAge());
	System.out.println("Student's rollNumber: " +obj.getRoll());
	
	// Direct access of Roll is not possible
	// due to encapsulation
	// System.out.println("Student's roll: " + obj.Name);
	}


}