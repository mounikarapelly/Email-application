package core;

//Extending thread class
 public class customer extends Thread
 	{
	 static Booking b1=new Booking();
	 int seat;
	 public void run()
	 {
		 try
		 { 
			 b1.bookseat(seat);
		 }
		 catch(NullPointerException e)
		 { 
			 e.printStackTrace();
		 }
	 }
}