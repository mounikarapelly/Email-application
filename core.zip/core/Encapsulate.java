package core;

public class Encapsulate {
    // private variables declared
	// these can only be accessed by public methods of class
	private String Name;
	private int Roll;
	private int Age;
	// get methods for age, name and roll
	//to access private variables
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public int getRoll() {
		return Roll;
	}
	public void setRoll(int roll) {
		Roll = roll;
	}
	public int getAge() {
		return Age;
	}
	public void setAge(int age) {
		Age = age;
	}
	
}
	