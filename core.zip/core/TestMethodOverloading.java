package core;

public class TestMethodOverloading {


	public static void main(String[] args){
	//Method Overloading: changing no. of arguments
	System.out.println(MethodOverloading.add(11,11));
	System.out.println(MethodOverloading.add(11,11,11));
	//Method Overloading: changing data type of arguments
	System.out.println(MethodOverloading.add(12.3,12.6));
	System.out.println(MethodOverloading.add("One","Three"));
	//Method Overloading: Sequence of data type of arguments
	MethodOverloading.disp("manish",5527);
	MethodOverloading.disp(9399,"hello");
	}
	}