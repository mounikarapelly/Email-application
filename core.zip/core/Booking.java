package core;

public class Booking 
{ 
	int total_seats=20;

	//Synchronized function
	synchronized void bookseat(int seats)
	{
		if(total_seats>=seats)
		{ 
			System.out.println("\nSeat Book Successfull...!!");
			total_seats=total_seats-seats;
			System.out.println("Total seat Left : "+total_seats);
		}
		else
		{ 
			System.out.println("\nSeat cannot be Booked");
			System.out.println("Only "+total_seats + " available");

		}
	}
}

