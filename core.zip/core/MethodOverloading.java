package core;

public class MethodOverloading {


	//Method Overloading: changing no. of arguments
	static int add(int a,int b){
		return a+b;
		}
	static int add(int a,int b,int c){
		return a+b+c;
		}
	//Method Overloading: changing data type of arguments
	static double add(double a, double b){
		return a+b;
		}
	static String add(String a, String b) {
	String str = "Four"; 
	return str;
	}
	//Method Overloading: Sequence of data type of arguments
	static void disp(String c, int num) {
	System.out.println(c +" "+ num);
	}
	static void disp(int num, String c)
	{
		System.out.println(num +" "+ c);}
	}
	