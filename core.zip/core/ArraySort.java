package core;

import java.util.Arrays;
import java.util.Scanner;

public class ArraySort {
		public static void main(String args[]){
		int []arr = new int[7];
		Scanner enter = new Scanner(System.in);
		System.out.println("enter 7 numbers perform sorting");
		for(int i=0; i<arr.length; i++)
		 {
			arr[i]=enter.nextInt();
		 }
		// Applying sort() method over to above array
		// by passing the array as an argument
		Arrays.sort(arr);
		System.out.println("\nSorting in Ascending order :\n");
		for(int i=0;i<arr.length;i++)
		{
		System.out.print(" "+arr[i]);
		}
		System.out.println( );

		}
}
