package core;
//new class
//Test implements interface CirclArea and RectangleArea
	
class Test implements CircleArea,RectangleArea
	{ 
		//the body of compute provided here
		public float compute(float x) { 
			return(pi*x*x);
			}
		//the body of calculate provided here
		public int calculate(int l,int w) { 
			return(l*w);
			}
}