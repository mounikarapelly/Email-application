package core;

public class AirthmeticOperstionsexample {
	public static void main(String args[])
	{ 
		ArithmeticOperations obj = new ArithmeticOperations();
	System.out.print("\nAddition : Enter Two Number - ");
	float result = ((ArithmeticOperations) obj).Addition();
	System.out.println("Result is :"+result);
	System.out.print("\nSubtraction : Enter Two Number - ");
	result = obj.Subtract();
	System.out.println("Result is :"+ result);
	System.out.print("\nMultiplication : Enter Two Number -");

	result = obj.Multiplication();
	System.out.println("Result is :"+result);
	System.out.print("\nDivision : Enter Two Number - ");
	result = obj.Division();
	System.out.println("Result is :"+result);
	}

}
