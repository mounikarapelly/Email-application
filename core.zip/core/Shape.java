package core;


abstract class Shape{
	//abstract method declaration, Abstract method (does not have not a body
	
	abstract public void areaCalcultion();
	abstract public void readData();
	}
