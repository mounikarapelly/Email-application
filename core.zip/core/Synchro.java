package core;

public class Synchro
{
	public static void main(String[] args)

	{
		customer C1=new customer();
		customer C2=new customer();
		C2.seat=19;
		C1.seat=8;
		C1.start();
		C2.start();
		//isAlive() method
		System.out.println(C1.isAlive());
		try
		{
			//Thread sleep() and join method
			C2.sleep(2000);
			C1.join();
		}
		catch (Exception e)
		{
			System.out.println("Exception : "+e.getMessage());
		}
	}
}