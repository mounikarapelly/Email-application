package core;

public interface CircleArea{
	final static float pi = 3.14F;
	float compute(float x); //interface method
}

 
 	
