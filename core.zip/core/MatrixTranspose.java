package core;

import java.util.Scanner;

public class MatrixTranspose {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int original[][]=new int[3][3] ;
		System.out.println("Enter the elements of matrix: ");
		for(int row = 0; row<3; row++)
		{
			for(int col = 0; col<3; col++)
			{ 
				original[row][col] = input.nextInt();
			}
		}
		int transpose[ ][ ] = new int[3][3];
		for(int row = 0; row<3; row++)
		{
			for(int col = 0; col<3; col++)
			{
				transpose[row][col] = original[col][row];
			}
		}
		System.out.println("Transpose of matrix : \n");
		for(int row = 0; row<3; row++)
		{ 
			for(int col = 0; col<3; col++)
			{
				System.out.print(" "+ transpose[row][col] );
			}
			System.out.print("\n");
		}
	}
}