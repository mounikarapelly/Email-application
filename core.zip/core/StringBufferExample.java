package core;

public class StringBufferExample {
	public static void main(String args[]){
		//initialized StringBuffer object
		StringBuffer sb = new StringBuffer("Good mornibg");
			System.out.println("\n"+sb);
		//append to String1
			sb.append(" Hello!!");
		//prints "Good Morning... Hello!!" after appending
			System.out.println(sb);
		//insert Namste!! with begining position 0
			sb.insert(0,"Namste!! ");
		//prints "Namste!! Good Morning... Hello!!"
			System.out.println(sb);
		// replace Morning with Evening
			sb.replace(13,20," Evening");
		//prints "Namste!! Good Morning... Hello!!"
			System.out.println(sb);
		//delete string begining with position 0 to 3
			sb.delete(0,8);
		//prints "Good Morning... Hello!!"
			System.out.println(sb);
		//StringBuffer reverse() Method
			sb.reverse();
			System.out.println(sb);
		//prints capacity of buffer
			System.out.println("capacity of buffer is: " +
					sb.capacity());
		}

}
