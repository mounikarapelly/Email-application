package core;

public class PolyConstructorOverloading 
{
	public static void main(String[] args) 
	{
		Fruit f = new Apple();
		f.show();
		f = new Orange();
		f.show();
	}
}
class Fruit
{
	void show()
	{
		System.out.println("Showing Fruit");
	}
}
class Apple extends Fruit
{
	public void show()
	{
		System.out.println("Showing Apple");
	}
}
class Orange extends Fruit
{
	public void show()
	{
		System.out.println("Showing Orange");
	}
}   
