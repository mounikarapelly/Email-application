package core;

import java.util.Scanner;
//m-digit number that is equal to the sum of the mth powers of their digits.
public class Armstrong {


public static void main(String []args)
{ 
	int n,sum=0,count=0;
    Scanner input= new Scanner(System.in);
    System.out.println("\n enter a number armstromg no or not");
    		

      int number =input.nextInt();
      int num=number;
      // Find total digits in num
      while(num!=0)
       { num=num/10;
          count++;
        }
          //Copy the value for number in num
      num=number;
      // Calculate sum of power of digits
     while (num != 0)
       { n=num%10;
       sum=sum+(int)Math.pow(n,count);
         num=num/10;
       }
         if (number == sum )
          System.out.println("\n"+number + " is an Armstrong number ");

         else
        System.out.println("\n"+number + " is not an Armstrong number ");
        	
     }
}