package core;

import java.util.Scanner;

public class SimpleInterest {
	
	public static void main(String args[]){
		int principleAmount, rate, time ,si;
		Scanner input = new Scanner(System.in);
		System.out.print("\nEnter principle amount : ");
		String p = input.nextLine();
		System.out.print("Enter rate : ");
		String r = input.nextLine();
		System.out.print("Enter time : ");
		String t = input.nextLine();
		principleAmount = Integer.parseInt(p);
		rate = Integer.parseInt(r);
		time = Integer.parseInt(t);
		si = (principleAmount * rate * time )/100;
		System.out.println("Simple Interest is : " + si );
		}

}
