package com.spring.security.repo;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.spring.security.entity.Student;
@Repository
public interface StudentRepository extends MongoRepository<Student, String> {

}
