package com.spring.security.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.spring.security.entity.Student;
import com.spring.security.repo.StudentRepository;

@Service
public class StudentService {
	@Autowired
	StudentRepository studentrepository;

	
	public Student createStudent(Student student) {
		// TODO Auto-generated method stub
		return studentrepository.save(student) ;
	}


	public Student getStudentbyId(String id) {
		// TODO Auto-generated method stub
		return null;
	}


	
}
