package com.spring.security.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.spring.security.entity.Student;
import com.spring.security.service.StudentService;

@RestController
public class StudentController {
	
	@Autowired
	StudentService studentsevice;
	
	@PostMapping("/create")
	public Student createStudent(Student student) {
		return studentsevice.createStudent(student);
		
	}
	
	
	

}
