package com.spring.security;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringMongoApplicationTests {

	@Test
	void contextLoads() {
	}

}
