package userDefinedException;

public class HDFCBank implements Bank {
	private double balance;

	@Override
	public void deposite(double amount) throws InvalidAmountException {
		if (amount <= 0) {
			throw new InvalidAmountException(amount + "is not valid");
		}
		balance = balance + amount;
	}

	@Override
	public double withdraw(double amount) throws InsufficientFundsException {
		if (balance < amount) {
			throw new InsufficientFundsException("insufficient funds");
		}
		balance = balance - amount;
		return amount;
	}

	@Override
	public void balanceEnquiry() {
		System.out.println("current balance = " + balance);
	}
}
