package userDefinedException;

public class InvalidAmountException extends Exception {
	public InvalidAmountException() {
		super();
	}

	public InvalidAmountException(String msg) {
		super(msg);
	}

}
//Define custom exceptions InvalidAmountException, 
//InsufficientFundsException to handle wrong operations 
//done by customers in deposit, and withdrawal operations.

//TestCases:

//Throw InvalidAmountException 
//if the user enters zero or �ve amount in deposit and withdraw operations.
//Throw InsufficientFundsException 
//if the user enters the amount greater than the balance in case of withdrawing operations.