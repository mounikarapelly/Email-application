package methodoverloading;

public class Cat {

}
