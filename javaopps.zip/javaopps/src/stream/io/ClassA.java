package stream.io;
import java.io.FileInputStream;
import java.io.FileOutputStream;

public class ClassA 
{	
	void fileOperations1() throws Exception
	{
		System.out.println("----------fileOperations 1------------");
		FileInputStream fis=new FileInputStream("C:\Users\mrapelly\Desktop\text1.txt");
		System.out.println("Connection created");
		int x;
		while((x=fis.read())!=-1)// 66!=-1
		{
			System.out.print((char)x);
		}
		System.out.println();
		System.out.print("Data reterived"); 
		fis.close();
	}
	void fileOperations2() throws Exception
	{
		System.out.println("----------fileOperations 2------------");
		FileOutputStream fos=new FileOutputStream("C:\Users\mrapelly\Desktop\text2.txt",true);// append mode
		System.out.println("Connection created");
		
		String s="tomorrow is friday";
		byte arr[]=s.getBytes();
		fos.write(arr);
		
		System.out.println("Data is written");
		fos.close();
	}
	
	void fileOperation3() throws Exception
	{
		System.out.println("----------fileOperations 3------------");
		FileInputStream fis=new FileInputStream("C:\Users\mrapelly\Downloads\download.jpg");
		FileOutputStream fos=new FileOutputStream("C:\Users\mrapelly\Downloads\download(1).jpg");
		
		System.out.println("Connection created");		
		int x;
		while((x=fis.read())!=-1)
		{
			fos.write(x);
		}
		System.out.println("Data copied");
		fis.close();
		fos.close();
	}
	
	public static void main(String[] args) throws Exception
	{
		ClassA aobj=new ClassA();
		//aobj.fileOperations1();
		//aobj.fileOperations2();
		aobj.fileOperation3();
	}
			
}