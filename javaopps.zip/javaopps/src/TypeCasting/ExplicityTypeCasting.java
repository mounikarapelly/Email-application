package TypeCasting;

public class ExplicityTypeCasting {
//converting larger datatypes to smaller datatypes
	//it is also call narrowing and casting downwords
	
	 public static void main(String[] args) {
		    double myDouble = 9.78d;
		    int myInt = (int) myDouble; // Manual casting: double to int

		    System.out.println(myDouble);   // Outputs 9.78
		    System.out.println(myInt);      // Outputs 9
		  }
}
