package Methodoverriding;

public class Cat extends Animal {
	
		  public void animalSound() {
		    System.out.println("The cat says: meowee meowwee");
		  }
		
}
