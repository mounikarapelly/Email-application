package absrtraction;

public class AbstarctDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
