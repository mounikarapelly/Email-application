package basics;

public class Object {
	public void meth1() {
		System.out.println("object is printing");
	}
    public void meth2() {
    	System.out.println("meth2");
    }
    public int meth3() {
    	System.out.println("primitive");
    	return 0;
    }
	public static void main(String[] args) {
		Object o= new Object();//creating object
		//o.meth1();
		o.meth2();//calling object
		o.meth3();
		

	}

}
