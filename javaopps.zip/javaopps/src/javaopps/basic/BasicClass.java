package javaopps.basic;

public class BasicClass {
	
	
	public void  dog() {
		System.out.println("");
	}

	public static void main(String[] args) {
		
	}

}
