package javaopps.basic;

public class Staticblock {
	static int x= m1();//static variable
	static {
		System.out.println("static block");
	}
	static int m1() {
		System.out.println("static method");
		return 0;
	}

	public static void main(String[] args) {
		System.out.println("main method");

	}

}
