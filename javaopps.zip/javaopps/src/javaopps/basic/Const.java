package javaopps.basic;

public class Const {

	public static void main(String[] args) {
		

	}

}
