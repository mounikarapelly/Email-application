package javaopps.basic;

public class Main2 {

	
		  public static void main(String[] args) {
		    Person myObj = new Person();
		    myObj.setName("John"); // Set the value of the name variable to "John"
		    System.out.println(myObj.getName());
		    myObj.setNo(2);
           System.out.println(myObj.getNo());		
           }
		}
	
	


