package javaopps.basic;

public class Encapsulation {
	private int RollNumber;
	private  String name;
	public int getRollNumber() {
		return RollNumber;
	}
	public void setRollNumber(int rollNumber) {
		RollNumber = rollNumber;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void display() {
		// TODO Auto-generated method stub
		
	}
	

}
