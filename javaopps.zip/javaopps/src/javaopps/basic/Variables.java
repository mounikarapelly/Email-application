package javaopps.basic;

public class Variables {
    int a=10;//instace 
    static int b=20;//static
    void cat() {
    	int c=30;//local variable
    	int b=100;
    	System.out.println("instamce"+a);
    	System.out.println("static"+ new Variables().b);
    	//System.out.println("static"+ b);
    	System.out.println("local"+c);
    }
    void dog() {
    	System.out.println("in===>"+a);
    	System.out.println("sts===>"+b);
    	//System.out.println("loc===>"+c);
    }
	public static void main(String[] args) {
		Variables v = new Variables();
		v.cat();
		v.dog();
		
		

	}

}
