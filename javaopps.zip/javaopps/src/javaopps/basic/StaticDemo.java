package javaopps.basic;

public class StaticDemo {
    
	    static String collagneame = "k.v.sangatan";
	    int StudentRillNO;
	    String StudentName ;
	    
	public StaticDemo(int studentRillNO, String studentName) {
	        super();
	        StudentRillNO = studentRillNO;
	        StudentName = studentName;
	        System.out.println("===");
	    }
	    void display()
	    {
	        System.out.println(collagneame + "  " + StudentRillNO + "  " + StudentName);
	    }
	public static void main(String[] args){
		StaticDemo d =new StaticDemo(22,"hh");
		d.display();
		
	    //StaticDemo s1 = new Static(221, "manoj");
	    //Static s2 = new Static(2212, "samanth");
	    //Static s3 = new Static(225, "kiran");
	    //Static s4 = new Static(261, "mounaka");
	    //s1.display();
	    //s2.display();
	    //s3.display();
	    //s4.display();
	}
	
}
