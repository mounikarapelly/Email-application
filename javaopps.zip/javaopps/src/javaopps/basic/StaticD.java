package javaopps.basic;

public class StaticD {

	public static void main(String[] args) {
		System.out.println("main ");
		StaticD.meth1();
		

	}
	static void  meth1() {
		System.out.println("static method");
		
		
	}
	static{
		System.out.println("block");
		StaticD.meth1();
		
	}

}
