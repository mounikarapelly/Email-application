package javaopps.basic;

public class ClassA {

	public static void main(String[] args) {
		
	}

}
