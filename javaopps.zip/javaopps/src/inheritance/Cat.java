package inheritance;

public class Cat extends Animal{
	public void  cat1() {
		System.out.println("cat sounds meow");
		
	}
	public static void main(String[] args) {
		Cat obj=new Cat();
		obj.cat1();
		
	}
}   
