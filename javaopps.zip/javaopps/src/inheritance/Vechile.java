package inheritance;

public class Vechile {
	protected String brand = "Ford";        // Vehicle attribute
	  public void honk() {                    // Vehicle method
	    System.out.println("honk honk!");
	  }
}
