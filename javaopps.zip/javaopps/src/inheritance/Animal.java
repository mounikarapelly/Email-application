package inheritance;

public class Animal {
	public void a1() {
		System.out.println(" cat sounds meow");
	}

}
