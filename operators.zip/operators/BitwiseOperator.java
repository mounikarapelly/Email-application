package operators;

public class BitwiseOperator {
    // bitwise operators applys the both boolean and interger types
	public static void main(String[] args) {
		System.out.println(4&5);
		System.out.println(4|5);
		System.out.println(4^5);
		System.out.println(true&true);
		System.out.println(true|false);
		
		System.out.println(true^false);
				//~it applies only interger);
	}

}
