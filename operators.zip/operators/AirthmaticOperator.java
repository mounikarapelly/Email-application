package operators;

public class AirthmaticOperator {

	public static void main(String[] args) {
		int x=100;
		int y=200;
		System.out.println("addition=="+(x+y));
		System.out.println("subtrsction=="+(x-y));
		System.out.println("multiplication=="+(x*y));
		System.out.println("division=="+(x/y));
		System.out.println("remonder=="+(x%y));

	}

}
