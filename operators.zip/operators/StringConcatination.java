package operators;

public class StringConcatination {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
         String s1= "xyz";
         String s2 ="abc";
         int a=10; 
         int b=20;
         int c=30;
         System.out.println(s1+s2);
         System.out.println(a+b+c);
         System.out.println(a+b+s1);
         System.out.println(s1+a+b+c);
	}

}
