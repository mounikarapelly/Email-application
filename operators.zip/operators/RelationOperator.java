package operators;

public class RelationOperator {

	public static void main(String[] args) {
		System.out.println(10 <=20);
		System.out.println('a'<10);
		System.out.println('a'>'A');
		System.out.println('a'>900);
		System.out.println((int)'a');
		System.out.println((int)'A');

	}

}
