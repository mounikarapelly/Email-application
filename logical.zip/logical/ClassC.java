package logical;

//given an array of intger ,
//return the sum of the first stmt 2 elemets in the arary.
//if the arary length is less than 2 
//just sum of the elements that exit, return0 if the arary length is 0
//1,2,3---3



public class ClassC {
	
	int meth3(int[] arr) {
		if(arr.length>=2) {
			return arr[0] + arr[1];
		}
		else if (arr.length==1) {
		return arr[0];
		}else
			
		return 0;
		
	}

	public static void main(String[] args) {
		ClassC c = new ClassC();
		int input[]= {};
		int result =c.meth3(input);
		System.out.println(result);


	}

}
