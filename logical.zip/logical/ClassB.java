package logical;


//given int an array of length 2,
//return true if they array doesn't contain 2 or 3
public class ClassB {
	
	
	boolean meth2(int[]arr) {
		if(arr[0]!=2 && arr[0]!=3 && arr[1]!=2&& arr[1]!=3)
		return false;
		return  true;
		
	}

	public static void main(String[] args) {
		
		ClassB b = new ClassB();
		int input[]= {2,3};
		boolean result= b.meth2(input);
		System.out.println(result);


	}

}
