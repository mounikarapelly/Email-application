package logical;



// give an int array length 3 ,if there is an 2 in the array immediately followed by a 3,
//chsnge the element 3 to 0 & return the changed array
//1 2 3== 1 2 0
//2 3 4 == 2 0 4
//1 2 2== 1 2 2 
public class ClassA {
	
	int[] meth() {
		
		int arr[]= {1,2,3};
		for(int i=0;i<arr.length-1;i++) {
			if(arr[i]==2 && arr[i+1]==3) {
				arr[i+1]=0;
			}
	}
		return arr;
	}
	public static void main(String[] args) {
		ClassA array = new ClassA();
		int result[]=array.meth();
		for(int x:result) {
			System.out.println(x+ " ");
		}
		
	}

}
