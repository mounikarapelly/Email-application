package pack2;

import java.util.Scanner;

public class Avgofarray {

	public static void main(String[] args) {
		
		  int[] array = { 1, 2, 3, 4, 5, 6 };
		  int length = array.length;
		  
		  // default sium value. 
		  int sum = 0;
		  
		  // sum of all values in array using for loop 
		  for (int i = 0; i < array.length; i++)
		  { 
			  sum += array[i]; 
			  }
		  
		  double average = sum / length;
		  
		  System.out.println("Average of array : "+average);
		  
		 
		
		// reading the array size.
      /*  Scanner s = new Scanner(System.in);
 
        System.out.println("Enter array size: ");
        int size = s.nextInt();
        int[] z = new int[size];// create an array
  
        System.out.println("Enter array values :  "); // reading values from user keyboard
        for (int i = 0; i < size; i++) {
            int value = s.nextInt();
            z[i] = value;
 
        }
 
        int length = z.length;// getting array length
 
        int sum = 0;// default sium value.
        for (int i = 0; i < z.length; i++) { // sum of all values in array using for loop
            sum += z[i];
        }
 
        double average = sum / length;
 
        System.out.println("Average of array : " + average);
 
		
		
		*/
		
		
	}

}
