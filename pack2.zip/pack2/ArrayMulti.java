package pack2;

public class ArrayMulti {

	public static void main(String[] args) {
		int arr[][]= {{1,2,3},{5,6,7},{8,9,12}};
		for(int i=0;i<3;i++) {
			for(int j=0;j<3;j++) {
				System.out.println(arr[i][j]+" ");
			}
			System.out.println();
		}
		
		/*int arr[][]={{1,2,3},{5,6,7},{8,9,12}}; //declaring and initializing 2D array    
		for(int i=0;i<3;i++){  //printing 2D array
		   for(int j=0;j<3;j++){  
		       System.out.print(arr[i][j]+" ");  
		   }  
		System.out.println();  
		}  */

	}

}
