package pack2;

public class ChangeArrayValue {
	
	    public static void main(String[] args) {
	      
	        int [] numbers = {1, 2, 3, 4, 5, 6};
	        int [] positiveNumbers = numbers;    // copying arrays
	      
	        // change value of first array by using index poistion
	        //indesx postion st with 0
	        
	        numbers[0] = -1;

	        // printing the second array using for each loop
	        for (int number: positiveNumbers) {
	            System.out.print(number + ", ");
	        }
	    
	}

}
