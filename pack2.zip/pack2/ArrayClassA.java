package pack2;

import java.util.Scanner;

public class ArrayClassA {
	
	void meth1() {
		int arr[]= new int[5];
		Scanner scanner = new Scanner(System.in);
		System.out.println("plz entwer "+arr.length+"  interger values");
		
		
		for(int i=0;i<arr.length;i++) {
			arr[i]=scanner.nextInt();
		}
		System.out.println("data entered");
		System.out.println("========");
		
		
		
		
		System.out.println("===========Reterving using for loop=========");
		
		for(int i=0;i<arr.length;i++) {
			System.out.println(arr[i]);
		}
		System.out.println("reterving the specific elements using for loop");
		System.out.println("============");
		
		for(int i=0;i<=3;i++) {
			System.out.println(arr[i]);
		}
		System.out.println("reterving in a reverse order ");
		
		
		
		for(int i=arr.length-2;i>=1;i--) {
			System.out.println(arr[i]);
			
		}
		System.out.println("==================");
		
		System.out.println("=====Reterving using for each loop===");
		for(int x:arr) {
			System.out.println(x);
		}
		
	}
	
	
	public static void main(String[] args) {
		new ArrayClassA().meth1();


	}

}
