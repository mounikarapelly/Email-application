package pack2;

import java.util.Arrays;

public class ChangeArrayConstru {
	
	
	
	    public static void main(String[] args) {
	      
	        int [] key = {1, 2, 3, 4, 5, 6};
	        int [] value = new int[6];

	        // iterate and copy elements from key to value
	        for (int i = 0; i < key.length; ++i) {
	            value[i] = key[i];
	        }
	       // System.out.println(key);
	      
	         // converting array to string
	       System.out.println(Arrays.toString(key));
	    }
	

}
