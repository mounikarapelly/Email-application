package pack2;

import pack1.Main1;

public class ArraydemoBasic {
	
	
	
	
	void main() {
		int arr[]=new int[5];
		//System.out.println(arr[2]);
		arr[0]=15;
		arr[1]=25;
		arr[2]=35;
		arr[3]=45;
		arr[4]=55;
		String s="array is container object";
		System.out.println("length of the array===>"+arr.length);
		System.out.println("length of the string=====>"+s.length());
		System.out.println("using loop");
		for(int x=0;x<arr.length;x++) {
			System.out.println(arr[x]);
			
		}
		
	}

	public static void main(String[] args) {
		
	  //ArraydemoBasic a = new ArraydemoBasic();
		new ArraydemoBasic().main();
	 


	}

}
