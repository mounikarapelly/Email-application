package pack2;

public class CopyArry {

	
	    public static void main(String[] args) {
	       
	        int [] numbers = {1, 2, 3, 4, 5, 6,7,8,9,10};
	        int [] positiveNumbers = numbers;    // copying arrays

	        for (int number: positiveNumbers) {//for ech loop
	            System.out.print(number + ", ");
	           // System.out.println(positiveNumbers+",");
	        }
	    }
	
}
