package pack2;

public class ArrayDemo13 {
	//creating a method which receives an array as a parameter  
			static void min(int arr[]){  
			int min=arr[0];  
			for(int i=1;i<arr.length;i++)  
			 if(min>arr[i])  
			  min=arr[i];  
			  
			System.out.println(min);  
			} 
			    
			
			static void max(int arr[]){  
				int max=arr[0];  
				for(int i=1;i<arr.length;i++)  
				 if(max<arr[i])  
				  max=arr[i];  
				  
				System.out.println(max);  
				} 
			
		public static void main(String args[]){  
		int a[]={1,2,3,4,5,6,7,8,9,10};//declaring and initializing an array  
		min(a);//passing array to method
		max(a);
		  
		}  
}
