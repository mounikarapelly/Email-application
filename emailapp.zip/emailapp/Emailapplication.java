package emailapp;

import java.util.Scanner;

public class Emailapplication {

	private String firstName;
	private String lastName;
	private String password;
	private String Department;
	private int mailboxCapacity = 500;
	private int defaultPasswordLength = 10;
	private String alternativemail;
	private String email;
	private String comapnysuffix = "capgemini.com";

	// Constructor for first&last name
	public Emailapplication(String firstName, String lastName) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		// System.out.println("Email Created==>" + this.firstName + " " +
		// this.lastName);

		// calling method asking for the department --return the department
		this.Department = setDepartment();
		// System.out.println("DEPARTMENT===>" + this.Department);

		// ca;l a method that retunrs the random password
		this.password = randomPassword(defaultPasswordLength);
		System.out.println("Your password is===>" + this.password);

		// combine elemtns to generate a mail
		email = firstName.toLowerCase() + "." + lastName.toLowerCase() + "@" + comapnysuffix;

		// email = firstName.toLowerCase() + "." + lastName.toLowerCase() + "@" +
		// Department + "." + comapnysuffix;
		// System.out.println("Capgemini mailId===>" + email);
	}

	// ask for the department
	private String setDepartment() {
		System.out.println(
				"ENTER THE DEPARTMENT \n1 for sales \n2 development \n3 foe accounting \n0 for none \n enter the department code");

		Scanner scanner = new Scanner(System.in);
		int depChoice = scanner.nextInt();

		if (depChoice == 1) {
			return "Sales";

		} else if (depChoice == 2) {
			return "developmemt";
		} else if (depChoice == 3) {
			return "Accounting";
		} else {
			return "none";
		}

	}

	// GEnerate a random password
	private String randomPassword(int length) {
		String passwordSet = "ABCDEFGHIGKLMNOPQRSTUVWXYZ1234567890@$";
		char[] password = new char[length];
		for (int i = 0; i < length; i++) {

			int rand = (int) (Math.random() * passwordSet.length());
			password[i] = passwordSet.charAt(rand);
			// System.out.println(rand);
			// System.out.println(passwordSet.charAt(rand));

		}
		return new String(password);

	}

	// set the mail box capacity
	public void SetMailboxCapacity(int capacity) {
		this.mailboxCapacity = capacity;
	}

	// set the alternative mail
	public void setAlternativeMail(String altEmail) {
		this.alternativemail = altEmail;
	}

	// change the password
	public void changePassword(String password) {
		this.password = password;
	}

	public int getMailboxCapacity() {
		return mailboxCapacity;
	}

	public String getAlternativeEmail() {
		return alternativemail;

	}

	public String getPassword() {
		return password;

	}

	public String showInfo() {

		return "DISPLAYNAME===>" + firstName + " " + lastName + "\nCOMPANY Email===>" + email
				+ "\nMAILBOX CAPACITY====>"
				+ mailboxCapacity + "mb";

	}

}
