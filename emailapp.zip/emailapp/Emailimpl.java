package emailapp;

public class Emailimpl {

	public static void main(String[] args) {
		Emailapplication em1 = new Emailapplication("mounika", "Rapelly");
		// em1.setAlternativeMail("mounikarapelly@gmail.com");
		// System.out.println(em1.getAlternativeEmail());
		System.out.println(em1.showInfo());
	}

}
